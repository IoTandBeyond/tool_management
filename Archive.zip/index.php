<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tool Management — Warehouse</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,600;0,9..40,700;1,9..40,400&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>
  <div class="wrap">
    <div class="kiosk-title">
      <h1>Warehouse tools</h1>
      <p class="sub">Scan or enter your employee ID, then choose borrow or return.</p>
    </div>
    <div class="card" style="max-width: 480px; margin: 0 auto;">
      <label for="employee_id">Employee ID / QR code</label>
      <input type="text" id="employee_id" name="employee_id" autocomplete="off" autofocus placeholder="e.g. OP-001">
      <div class="row-actions" style="margin-top: 1rem;">
        <button type="button" class="btn btn-primary" id="btn-checkout">Borrow tools</button>
        <button type="button" class="btn btn-secondary" id="btn-return">Return tools</button>
      </div>
      <div id="id-error" class="msg msg-error" style="display: none; margin-top: 1rem;"></div>
    </div>
    <div class="kiosk-footer">
      <a href="login.php">Supervisor login</a>
    </div>
  </div>
  <script src="assets/js/api.js"></script>
  <script>
    (function () {
      var input = document.getElementById('employee_id');
      var err = document.getElementById('id-error');

      function go(flow) {
        err.style.display = 'none';
        var id = (input.value || '').trim();
        if (!id) {
          err.textContent = 'Enter or scan your employee ID first.';
          err.style.display = 'block';
          input.focus();
          return;
        }
        tmApi('validate_operator', { employee_id: id }).then(function (data) {
          if (!data.ok) {
            err.textContent = data.error || 'Validation failed';
            err.style.display = 'block';
            return;
          }
          var q = 'operator_id=' + encodeURIComponent(data.operator.id) +
            '&name=' + encodeURIComponent(data.operator.name);
          if (flow === 'checkout') {
            window.location.href = 'checkout.php?' + q;
          } else {
            window.location.href = 'return.php?' + q;
          }
        }).catch(function () {
          err.textContent = 'Network error — try again.';
          err.style.display = 'block';
        });
      }

      document.getElementById('btn-checkout').addEventListener('click', function () { go('checkout'); });
      document.getElementById('btn-return').addEventListener('click', function () { go('return'); });
      input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          go('checkout');
        }
      });
    })();
  </script>
</body>
</html>
