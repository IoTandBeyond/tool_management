/**
 * JSON API helper — kiosk calls use no credentials; supervisor calls use cookies.
 */
async function tmApi(action, payload = {}, withCredentials = false) {
  const url = 'api.php?action=' + encodeURIComponent(action);
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: withCredentials ? 'same-origin' : 'omit',
    body: JSON.stringify({ action, ...payload }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok && !data.error) {
    throw new Error(res.statusText || 'Request failed');
  }
  return data;
}

function tmFormatDt(iso) {
  if (!iso) return '—';
  try {
    const d = new Date(iso.replace(' ', 'T'));
    return d.toLocaleString();
  } catch {
    return iso;
  }
}
