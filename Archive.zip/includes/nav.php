<?php
/** @var string $active */
$active = $active ?? '';
?>
<nav class="topnav">
  <div>
    <span class="brand">Tool Management</span>
  </div>
  <div>
    <a href="dashboard.php" class="<?= $active === 'dashboard' ? 'active' : '' ?>">Dashboard</a>
    <a href="tools.php" class="<?= $active === 'tools' ? 'active' : '' ?>">Tools</a>
    <a href="operators.php" class="<?= $active === 'operators' ? 'active' : '' ?>">Operators</a>
    <a href="history.php" class="<?= $active === 'history' ? 'active' : '' ?>">History &amp; reports</a>
    <a href="#" id="nav-logout">Logout</a>
  </div>
</nav>
