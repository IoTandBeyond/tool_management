<?php
declare(strict_types=1);

function tm_json_response(array $data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    exit;
}

function tm_require_supervisor(): void
{
    if (empty($_SESSION['supervisor_id'])) {
        tm_json_response(['ok' => false, 'error' => 'Unauthorized'], 401);
    }
}

function tm_log_activity(string $type, string $message, ?array $meta = null): void
{
    $pdo = tm_db();
    $stmt = $pdo->prepare(
        'INSERT INTO activity_log (event_type, message, meta) VALUES (?, ?, ?)'
    );
    $metaJson = $meta === null ? null : json_encode($meta, JSON_THROW_ON_ERROR);
    $stmt->execute([$type, $message, $metaJson]);
}

function tm_expected_return_at(): string
{
    global $config;
    $hours = (int) ($config['expected_return_hours'] ?? 48);
    return (new DateTimeImmutable("+{$hours} hours"))->format('Y-m-d H:i:s');
}
