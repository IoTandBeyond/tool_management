<?php $active = 'tools'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tools</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,600;0,9..40,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>
  <?php require __DIR__ . '/includes/nav.php'; ?>
  <div class="wrap">
    <h1>Tools</h1>
    <p class="sub">Add, edit, or remove tools. Barcode must be unique; NFC is optional.</p>
    <div class="row-actions" style="margin-bottom: 1rem;">
      <button type="button" class="btn btn-primary" id="btn-add">Add tool</button>
    </div>
    <div id="msg"></div>
    <div class="card" style="overflow-x: auto;">
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Barcode</th>
            <th>NFC</th>
            <th>Category</th>
            <th>Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody id="tbody"></tbody>
      </table>
    </div>
  </div>

  <div id="modal" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.65); z-index: 20; align-items: center; justify-content: center; padding: 1rem;">
    <div class="card" style="max-width: 480px; width: 100%; max-height: 90vh; overflow-y: auto;">
      <h2 id="modal-title">Tool</h2>
      <input type="hidden" id="f-id">
      <label for="f-name">Name</label>
      <input type="text" id="f-name">
      <label for="f-barcode" style="margin-top: 0.75rem;">Barcode</label>
      <input type="text" id="f-barcode">
      <label for="f-nfc" style="margin-top: 0.75rem;">NFC ID (optional)</label>
      <input type="text" id="f-nfc">
      <label for="f-cat" style="margin-top: 0.75rem;">Category</label>
      <select id="f-cat"></select>
      <label for="f-desc" style="margin-top: 0.75rem;">Description</label>
      <textarea id="f-desc"></textarea>
      <label for="f-status" style="margin-top: 0.75rem;">Status</label>
      <select id="f-status">
        <option value="available">Available</option>
        <option value="checked_out">Checked out</option>
        <option value="missing">Missing</option>
      </select>
      <div class="row-actions" style="margin-top: 1rem;">
        <button type="button" class="btn btn-primary" id="f-save">Save</button>
        <button type="button" class="btn btn-secondary" id="f-close">Close</button>
      </div>
    </div>
  </div>

  <script src="assets/js/api.js"></script>
  <script>
    (function () {
      var categories = [];

      function ensureAuth() {
        return tmApi('me', {}, true).then(function (data) {
          if (!data.logged_in) {
            window.location.href = 'login.php';
            return false;
          }
          return true;
        });
      }

      function badge(status) {
        var c = 'badge-available';
        if (status === 'checked_out') c = 'badge-out';
        if (status === 'missing') c = 'badge-missing';
        return '<span class="badge ' + c + '">' + status.replace('_', ' ') + '</span>';
      }

      function loadCategories() {
        return tmApi('categories_list', {}, true).then(function (data) {
          categories = data.categories || [];
          var sel = document.getElementById('f-cat');
          sel.innerHTML = '<option value="">— None —</option>';
          categories.forEach(function (c) {
            var o = document.createElement('option');
            o.value = c.id;
            o.textContent = c.name;
            sel.appendChild(o);
          });
        });
      }

      function loadTools() {
        tmApi('tools_list', {}, true).then(function (data) {
          var tb = document.getElementById('tbody');
          tb.innerHTML = '';
          (data.tools || []).forEach(function (t) {
            var tr = document.createElement('tr');
            tr.innerHTML =
              '<td>' + escapeHtml(t.name) + '</td>' +
              '<td>' + escapeHtml(t.barcode) + '</td>' +
              '<td>' + escapeHtml(t.nfc_id || '—') + '</td>' +
              '<td>' + escapeHtml(t.category_name || '—') + '</td>' +
              '<td>' + badge(t.status) + '</td>' +
              '<td><button type="button" class="btn btn-ghost btn-edit" data-id="' + t.id + '">Edit</button> ' +
              '<button type="button" class="btn btn-danger btn-del" data-id="' + t.id + '">Delete</button></td>';
            tb.appendChild(tr);
          });
          tb.querySelectorAll('.btn-edit').forEach(function (b) {
            b.addEventListener('click', function () { openEdit(parseInt(b.dataset.id, 10)); });
          });
          tb.querySelectorAll('.btn-del').forEach(function (b) {
            b.addEventListener('click', function () {
              if (!confirm('Delete this tool?')) return;
              tmApi('tool_delete', { id: parseInt(b.dataset.id, 10) }, true).then(function (r) {
                if (r.ok) loadTools();
                else alert(r.error || 'Delete failed');
              });
            });
          });
        });
      }

      function escapeHtml(s) {
        var d = document.createElement('div');
        d.textContent = s;
        return d.innerHTML;
      }

      function openAdd() {
        document.getElementById('modal-title').textContent = 'Add tool';
        document.getElementById('f-id').value = '';
        document.getElementById('f-name').value = '';
        document.getElementById('f-barcode').value = '';
        document.getElementById('f-nfc').value = '';
        document.getElementById('f-desc').value = '';
        document.getElementById('f-status').value = 'available';
        document.getElementById('f-cat').value = '';
        document.getElementById('modal').style.display = 'flex';
      }

      function openEdit(id) {
        tmApi('tools_list', {}, true).then(function (data) {
          var t = (data.tools || []).find(function (x) { return x.id === id; });
          if (!t) return;
          document.getElementById('modal-title').textContent = 'Edit tool';
          document.getElementById('f-id').value = t.id;
          document.getElementById('f-name').value = t.name;
          document.getElementById('f-barcode').value = t.barcode;
          document.getElementById('f-nfc').value = t.nfc_id || '';
          document.getElementById('f-desc').value = t.description || '';
          document.getElementById('f-status').value = t.status;
          document.getElementById('f-cat').value = t.category_id || '';
          document.getElementById('modal').style.display = 'flex';
        });
      }

      document.getElementById('btn-add').addEventListener('click', openAdd);
      document.getElementById('f-close').addEventListener('click', function () {
        document.getElementById('modal').style.display = 'none';
      });
      document.getElementById('f-save').addEventListener('click', function () {
        var payload = {
          id: document.getElementById('f-id').value ? parseInt(document.getElementById('f-id').value, 10) : undefined,
          name: document.getElementById('f-name').value.trim(),
          barcode: document.getElementById('f-barcode').value.trim(),
          nfc_id: document.getElementById('f-nfc').value.trim(),
          category_id: document.getElementById('f-cat').value || null,
          description: document.getElementById('f-desc').value.trim(),
          status: document.getElementById('f-status').value
        };
        tmApi('tool_save', payload, true).then(function (r) {
          if (r.ok) {
            document.getElementById('modal').style.display = 'none';
            loadTools();
          } else {
            alert(r.error || 'Save failed');
          }
        });
      });

      document.getElementById('nav-logout').addEventListener('click', function (e) {
        e.preventDefault();
        tmApi('logout', {}, true).then(function () { window.location.href = 'login.php'; });
      });

      ensureAuth().then(function (ok) {
        if (!ok) return;
        loadCategories().then(function () {
          loadTools();
        });
      });
    })();
  </script>
</body>
</html>
