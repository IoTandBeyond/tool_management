-- Warehouse Tool Management — database schema
-- Import: mysql -u root -p < sql/schema.sql

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS tool_management
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE tool_management;

DROP TABLE IF EXISTS activity_log;
DROP TABLE IF EXISTS transactions;
DROP TABLE IF EXISTS tools;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS operators;
DROP TABLE IF EXISTS supervisors;

CREATE TABLE supervisors (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(64) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE operators (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  employee_id VARCHAR(64) NOT NULL UNIQUE,
  department VARCHAR(120) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_employee (employee_id)
) ENGINE=InnoDB;

CREATE TABLE tools (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  barcode VARCHAR(128) NOT NULL,
  nfc_id VARCHAR(128) DEFAULT NULL,
  category_id INT UNSIGNED DEFAULT NULL,
  description TEXT,
  status ENUM('available','checked_out','missing') NOT NULL DEFAULT 'available',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_barcode (barcode),
  UNIQUE KEY uq_nfc (nfc_id),
  INDEX idx_status (status),
  CONSTRAINT fk_tools_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE transactions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  tool_id INT UNSIGNED NOT NULL,
  operator_id INT UNSIGNED NOT NULL,
  checkout_at DATETIME NOT NULL,
  checkin_at DATETIME DEFAULT NULL,
  expected_return_at DATETIME NOT NULL,
  CONSTRAINT fk_tx_tool FOREIGN KEY (tool_id) REFERENCES tools(id) ON DELETE RESTRICT,
  CONSTRAINT fk_tx_operator FOREIGN KEY (operator_id) REFERENCES operators(id) ON DELETE RESTRICT,
  INDEX idx_open (checkin_at),
  INDEX idx_checkout (checkout_at),
  INDEX idx_expected (expected_return_at)
) ENGINE=InnoDB;

CREATE TABLE activity_log (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  event_type VARCHAR(64) NOT NULL,
  message VARCHAR(512) NOT NULL,
  meta TEXT DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_created (created_at)
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;

-- Seed: default supervisor — username: admin | password: password (change immediately)
INSERT INTO supervisors (username, password_hash) VALUES
  ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

INSERT INTO categories (name) VALUES
  ('Hand tools'), ('Power tools'), ('Measuring'), ('Safety'), ('Other');

INSERT INTO operators (name, employee_id, department) VALUES
  ('Demo Operator', 'OP-001', 'Maintenance'),
  ('Jane Smith', 'OP-002', 'Assembly');

INSERT INTO tools (name, barcode, nfc_id, category_id, description, status) VALUES
  ('Cordless drill', 'BC-DRILL-001', 'NFC-DRILL-001', 2, '18V cordless drill', 'available'),
  ('Torque wrench', 'BC-TW-001', NULL, 1, '20-200 Nm', 'available'),
  ('Laser measure', 'BC-LM-001', 'NFC-LM-001', 3, NULL, 'available');
