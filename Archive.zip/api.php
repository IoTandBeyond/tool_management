<?php
declare(strict_types=1);

header('X-Content-Type-Options: nosniff');

require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/auth_supervisor.php';

$raw = file_get_contents('php://input');
$input = $raw !== '' && $raw !== false ? json_decode($raw, true, 512, JSON_THROW_ON_ERROR) : [];
$action = $_GET['action'] ?? ($input['action'] ?? '');

if ($action === '') {
    tm_json_response(['ok' => false, 'error' => 'Missing action'], 400);
}

$pdo = tm_db();

switch ($action) {

    case 'validate_operator': {
        $employeeId = trim((string) ($input['employee_id'] ?? ''));
        if ($employeeId === '') {
            tm_json_response(['ok' => false, 'error' => 'Employee ID required'], 400);
        }
        $stmt = $pdo->prepare('SELECT id, name, employee_id, department FROM operators WHERE employee_id = ? LIMIT 1');
        $stmt->execute([$employeeId]);
        $op = $stmt->fetch();
        if (!$op) {
            tm_json_response(['ok' => false, 'error' => 'Employee ID not found'], 404);
        }
        tm_json_response(['ok' => true, 'operator' => $op]);
    }

    case 'operator_borrowed': {
        $operatorId = (int) ($input['operator_id'] ?? 0);
        if ($operatorId < 1) {
            tm_json_response(['ok' => false, 'error' => 'Invalid operator'], 400);
        }
        $stmt = $pdo->prepare(
            'SELECT t.id AS transaction_id, t.checkout_at, t.expected_return_at,
                    t.tool_id, tl.name AS tool_name, tl.barcode, tl.nfc_id, tl.status
             FROM transactions t
             INNER JOIN tools tl ON tl.id = t.tool_id
             WHERE t.operator_id = ? AND t.checkin_at IS NULL
             ORDER BY t.checkout_at DESC'
        );
        $stmt->execute([$operatorId]);
        $rows = $stmt->fetchAll();
        tm_json_response(['ok' => true, 'borrowed' => $rows]);
    }

    case 'checkout_tool': {
        $operatorId = (int) ($input['operator_id'] ?? 0);
        $code = trim((string) ($input['code'] ?? ''));
        if ($operatorId < 1 || $code === '') {
            tm_json_response(['ok' => false, 'error' => 'Operator and scan code required'], 400);
        }
        $stmt = $pdo->prepare('SELECT id FROM operators WHERE id = ? LIMIT 1');
        $stmt->execute([$operatorId]);
        if (!$stmt->fetch()) {
            tm_json_response(['ok' => false, 'error' => 'Invalid operator'], 400);
        }
        $stmt = $pdo->prepare(
            'SELECT id, name, barcode, nfc_id, status FROM tools WHERE barcode = ? OR (nfc_id IS NOT NULL AND nfc_id = ?) LIMIT 1'
        );
        $stmt->execute([$code, $code]);
        $tool = $stmt->fetch();
        if (!$tool) {
            tm_json_response(['ok' => false, 'error' => 'Tool not found for this code'], 404);
        }
        if ($tool['status'] === 'missing') {
            tm_json_response(['ok' => false, 'error' => 'Tool is marked missing — contact a supervisor'], 409);
        }
        if ($tool['status'] !== 'available') {
            tm_json_response(['ok' => false, 'error' => 'Tool is not available'], 409);
        }
        $expected = tm_expected_return_at();
        $pdo->beginTransaction();
        try {
            $ins = $pdo->prepare(
                'INSERT INTO transactions (tool_id, operator_id, checkout_at, checkin_at, expected_return_at)
                 VALUES (?, ?, NOW(), NULL, ?)'
            );
            $ins->execute([(int) $tool['id'], $operatorId, $expected]);
            $upd = $pdo->prepare("UPDATE tools SET status = 'checked_out' WHERE id = ? AND status = 'available'");
            $upd->execute([(int) $tool['id']]);
            if ($upd->rowCount() !== 1) {
                throw new RuntimeException('Concurrent checkout conflict');
            }
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            tm_json_response(['ok' => false, 'error' => 'Could not check out tool — try again'], 409);
        }
        tm_log_activity('checkout', 'Tool checked out', [
            'tool_id' => (int) $tool['id'],
            'operator_id' => $operatorId,
        ]);
        tm_json_response([
            'ok' => true,
            'tool' => ['id' => (int) $tool['id'], 'name' => $tool['name'], 'barcode' => $tool['barcode']],
            'expected_return_at' => $expected,
        ]);
    }

    case 'return_tool': {
        $operatorId = (int) ($input['operator_id'] ?? 0);
        $toolId = (int) ($input['tool_id'] ?? 0);
        $code = trim((string) ($input['code'] ?? ''));
        if ($operatorId < 1 || $toolId < 1 || $code === '') {
            tm_json_response(['ok' => false, 'error' => 'Operator, tool, and scan code required'], 400);
        }
        $stmt = $pdo->prepare(
            'SELECT id, name, barcode, nfc_id FROM tools WHERE id = ? LIMIT 1'
        );
        $stmt->execute([$toolId]);
        $tool = $stmt->fetch();
        if (!$tool) {
            tm_json_response(['ok' => false, 'error' => 'Tool not found'], 404);
        }
        $match = ($tool['barcode'] === $code) || ($tool['nfc_id'] !== null && $tool['nfc_id'] === $code);
        if (!$match) {
            tm_json_response(['ok' => false, 'error' => 'Scanned code does not match this tool — please scan the correct item'], 409);
        }
        $stmt = $pdo->prepare(
            'SELECT id FROM transactions WHERE tool_id = ? AND operator_id = ? AND checkin_at IS NULL LIMIT 1'
        );
        $stmt->execute([$toolId, $operatorId]);
        $tx = $stmt->fetch();
        if (!$tx) {
            tm_json_response(['ok' => false, 'error' => 'No open checkout for this tool and operator'], 409);
        }
        $pdo->beginTransaction();
        try {
            $pdo->prepare('UPDATE transactions SET checkin_at = NOW() WHERE id = ?')->execute([(int) $tx['id']]);
            $pdo->prepare("UPDATE tools SET status = 'available' WHERE id = ?")->execute([$toolId]);
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            tm_json_response(['ok' => false, 'error' => 'Could not complete return'], 409);
        }
        tm_log_activity('return', 'Tool returned', ['tool_id' => $toolId, 'operator_id' => $operatorId]);
        tm_json_response(['ok' => true, 'tool' => ['id' => $toolId, 'name' => $tool['name']]]);
    }

    case 'dashboard_stats': {
        tm_require_supervisor();
        $inStock = (int) $pdo->query("SELECT COUNT(*) FROM tools WHERE status = 'available'")->fetchColumn();
        $checkedOut = (int) $pdo->query("SELECT COUNT(*) FROM tools WHERE status = 'checked_out'")->fetchColumn();
        $missing = (int) $pdo->query("SELECT COUNT(*) FROM tools WHERE status = 'missing'")->fetchColumn();
        $overdue = (int) $pdo->query(
            'SELECT COUNT(*) FROM transactions WHERE checkin_at IS NULL AND expected_return_at < NOW()'
        )->fetchColumn();
        tm_json_response([
            'ok' => true,
            'stats' => [
                'in_stock' => $inStock,
                'checked_out' => $checkedOut,
                'missing' => $missing,
                'overdue_transactions' => $overdue,
            ],
        ]);
    }

    case 'activity_feed': {
        tm_require_supervisor();
        $limit = min(50, max(1, (int) ($input['limit'] ?? 20)));
        $stmt = $pdo->prepare(
            'SELECT id, event_type, message, created_at FROM activity_log ORDER BY id DESC LIMIT ?'
        );
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->execute();
        tm_json_response(['ok' => true, 'items' => $stmt->fetchAll()]);
    }

    case 'login': {
        $username = trim((string) ($input['username'] ?? ''));
        $password = (string) ($input['password'] ?? '');
        if ($username === '' || $password === '') {
            tm_json_response(['ok' => false, 'error' => 'Username and password required'], 400);
        }
        $stmt = $pdo->prepare('SELECT id, username, password_hash FROM supervisors WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $row = $stmt->fetch();
        if (!$row || !password_verify($password, $row['password_hash'])) {
            tm_json_response(['ok' => false, 'error' => 'Invalid credentials'], 401);
        }
        $_SESSION['supervisor_id'] = (int) $row['id'];
        $_SESSION['supervisor_username'] = $row['username'];
        tm_json_response(['ok' => true, 'username' => $row['username']]);
    }

    case 'logout': {
        tm_require_supervisor();
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
        tm_json_response(['ok' => true]);
    }

    case 'me': {
        if (empty($_SESSION['supervisor_id'])) {
            tm_json_response(['ok' => false, 'logged_in' => false]);
        }
        tm_json_response(['ok' => true, 'logged_in' => true, 'username' => $_SESSION['supervisor_username'] ?? '']);
    }

    case 'categories_list': {
        tm_require_supervisor();
        $rows = $pdo->query('SELECT id, name FROM categories ORDER BY name')->fetchAll();
        tm_json_response(['ok' => true, 'categories' => $rows]);
    }

    case 'tools_list': {
        tm_require_supervisor();
        $sql = 'SELECT t.id, t.name, t.barcode, t.nfc_id, t.description, t.status, t.created_at,
                       c.name AS category_name, c.id AS category_id
                FROM tools t
                LEFT JOIN categories c ON c.id = t.category_id
                ORDER BY t.name';
        tm_json_response(['ok' => true, 'tools' => $pdo->query($sql)->fetchAll()]);
    }

    case 'tool_save': {
        tm_require_supervisor();
        $id = isset($input['id']) ? (int) $input['id'] : 0;
        $name = trim((string) ($input['name'] ?? ''));
        $barcode = trim((string) ($input['barcode'] ?? ''));
        $nfc = trim((string) ($input['nfc_id'] ?? ''));
        $nfc = $nfc === '' ? null : $nfc;
        $categoryId = isset($input['category_id']) && $input['category_id'] !== '' ? (int) $input['category_id'] : null;
        $description = trim((string) ($input['description'] ?? ''));
        $status = (string) ($input['status'] ?? 'available');
        if (!in_array($status, ['available', 'checked_out', 'missing'], true)) {
            $status = 'available';
        }
        if ($name === '' || $barcode === '') {
            tm_json_response(['ok' => false, 'error' => 'Name and barcode required'], 400);
        }
        if ($id > 0) {
            $stmt = $pdo->prepare(
                'UPDATE tools SET name=?, barcode=?, nfc_id=?, category_id=?, description=?, status=? WHERE id=?'
            );
            $stmt->execute([$name, $barcode, $nfc, $categoryId, $description, $status, $id]);
            tm_json_response(['ok' => true, 'id' => $id]);
        }
        $stmt = $pdo->prepare(
            'INSERT INTO tools (name, barcode, nfc_id, category_id, description, status) VALUES (?,?,?,?,?,?)'
        );
        $stmt->execute([$name, $barcode, $nfc, $categoryId, $description, $status]);
        tm_json_response(['ok' => true, 'id' => (int) $pdo->lastInsertId()]);
    }

    case 'tool_delete': {
        tm_require_supervisor();
        $id = (int) ($input['id'] ?? 0);
        if ($id < 1) {
            tm_json_response(['ok' => false, 'error' => 'Invalid id'], 400);
        }
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM transactions WHERE tool_id = ? AND checkin_at IS NULL');
        $stmt->execute([$id]);
        if ((int) $stmt->fetchColumn() > 0) {
            tm_json_response(['ok' => false, 'error' => 'Cannot delete: tool has active checkouts'], 409);
        }
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM transactions WHERE tool_id = ?');
        $stmt->execute([$id]);
        if ((int) $stmt->fetchColumn() > 0) {
            tm_json_response(['ok' => false, 'error' => 'Cannot delete: this tool has transaction history — mark as Missing instead'], 409);
        }
        $pdo->prepare('DELETE FROM tools WHERE id = ?')->execute([$id]);
        tm_json_response(['ok' => true]);
    }

    case 'operators_list': {
        tm_require_supervisor();
        tm_json_response(['ok' => true, 'operators' => $pdo->query('SELECT id, name, employee_id, department, created_at FROM operators ORDER BY name')->fetchAll()]);
    }

    case 'operator_save': {
        tm_require_supervisor();
        $id = isset($input['id']) ? (int) $input['id'] : 0;
        $name = trim((string) ($input['name'] ?? ''));
        $emp = trim((string) ($input['employee_id'] ?? ''));
        $dept = trim((string) ($input['department'] ?? ''));
        $dept = $dept === '' ? null : $dept;
        if ($name === '' || $emp === '') {
            tm_json_response(['ok' => false, 'error' => 'Name and employee ID required'], 400);
        }
        if ($id > 0) {
            $pdo->prepare('UPDATE operators SET name=?, employee_id=?, department=? WHERE id=?')->execute([$name, $emp, $dept, $id]);
            tm_json_response(['ok' => true, 'id' => $id]);
        }
        $stmt = $pdo->prepare('INSERT INTO operators (name, employee_id, department) VALUES (?,?,?)');
        $stmt->execute([$name, $emp, $dept]);
        tm_json_response(['ok' => true, 'id' => (int) $pdo->lastInsertId()]);
    }

    case 'operator_delete': {
        tm_require_supervisor();
        $id = (int) ($input['id'] ?? 0);
        if ($id < 1) {
            tm_json_response(['ok' => false, 'error' => 'Invalid id'], 400);
        }
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM transactions WHERE operator_id = ? AND checkin_at IS NULL');
        $stmt->execute([$id]);
        if ((int) $stmt->fetchColumn() > 0) {
            tm_json_response(['ok' => false, 'error' => 'Cannot delete: operator has tools checked out'], 409);
        }
        $pdo->prepare('DELETE FROM operators WHERE id = ?')->execute([$id]);
        tm_json_response(['ok' => true]);
    }

    case 'history': {
        tm_require_supervisor();
        $op = isset($input['operator_id']) ? (int) $input['operator_id'] : 0;
        $tool = isset($input['tool_id']) ? (int) $input['tool_id'] : 0;
        $from = trim((string) ($input['date_from'] ?? ''));
        $to = trim((string) ($input['date_to'] ?? ''));
        $sql = 'SELECT tr.id, tr.checkout_at, tr.checkin_at, tr.expected_return_at,
                       o.name AS operator_name, o.employee_id,
                       tl.name AS tool_name, tl.barcode
                FROM transactions tr
                INNER JOIN operators o ON o.id = tr.operator_id
                INNER JOIN tools tl ON tl.id = tr.tool_id
                WHERE 1=1';
        $params = [];
        if ($op > 0) {
            $sql .= ' AND tr.operator_id = ?';
            $params[] = $op;
        }
        if ($tool > 0) {
            $sql .= ' AND tr.tool_id = ?';
            $params[] = $tool;
        }
        if ($from !== '') {
            $sql .= ' AND tr.checkout_at >= ?';
            $params[] = $from . ' 00:00:00';
        }
        if ($to !== '') {
            $sql .= ' AND tr.checkout_at <= ?';
            $params[] = $to . ' 23:59:59';
        }
        $sql .= ' ORDER BY tr.checkout_at DESC LIMIT 500';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        tm_json_response(['ok' => true, 'transactions' => $stmt->fetchAll()]);
    }

    case 'report_checked_out_by_operator': {
        tm_require_supervisor();
        $sql = 'SELECT o.id, o.name, o.employee_id, COUNT(t.id) AS open_count
                FROM operators o
                INNER JOIN transactions t ON t.operator_id = o.id AND t.checkin_at IS NULL
                GROUP BY o.id, o.name, o.employee_id
                ORDER BY open_count DESC';
        tm_json_response(['ok' => true, 'rows' => $pdo->query($sql)->fetchAll()]);
    }

    case 'report_overdue': {
        tm_require_supervisor();
        $sql = 'SELECT t.id, t.checkout_at, t.expected_return_at,
                       o.name AS operator_name, o.employee_id,
                       tl.name AS tool_name, tl.barcode
                FROM transactions t
                INNER JOIN operators o ON o.id = t.operator_id
                INNER JOIN tools tl ON tl.id = t.tool_id
                WHERE t.checkin_at IS NULL AND t.expected_return_at < NOW()
                ORDER BY t.expected_return_at ASC';
        tm_json_response(['ok' => true, 'rows' => $pdo->query($sql)->fetchAll()]);
    }

    case 'report_long_outstanding': {
        tm_require_supervisor();
        global $config;
        $days = (int) ($config['long_outstanding_days'] ?? 30);
        $stmt = $pdo->prepare(
            'SELECT t.id, t.checkout_at, t.expected_return_at,
                    o.name AS operator_name, o.employee_id,
                    tl.name AS tool_name, tl.barcode
             FROM transactions t
             INNER JOIN operators o ON o.id = t.operator_id
             INNER JOIN tools tl ON tl.id = t.tool_id
             WHERE t.checkin_at IS NULL AND t.checkout_at < DATE_SUB(NOW(), INTERVAL ? DAY)
             ORDER BY t.checkout_at ASC'
        );
        $stmt->execute([$days]);
        tm_json_response(['ok' => true, 'days_threshold' => $days, 'rows' => $stmt->fetchAll()]);
    }

    case 'report_missing_tools': {
        tm_require_supervisor();
        $sql = "SELECT id, name, barcode, nfc_id, description, updated_at FROM tools WHERE status = 'missing' ORDER BY name";
        tm_json_response(['ok' => true, 'rows' => $pdo->query($sql)->fetchAll()]);
    }

    case 'report_most_used_tools': {
        tm_require_supervisor();
        $limit = min(50, max(1, (int) ($input['limit'] ?? 20)));
        $stmt = $pdo->prepare(
            'SELECT tl.id, tl.name, tl.barcode, COUNT(tr.id) AS checkout_count
             FROM transactions tr
             INNER JOIN tools tl ON tl.id = tr.tool_id
             GROUP BY tl.id, tl.name, tl.barcode
             ORDER BY checkout_count DESC
             LIMIT ?'
        );
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->execute();
        tm_json_response(['ok' => true, 'rows' => $stmt->fetchAll()]);
    }

    default:
        tm_json_response(['ok' => false, 'error' => 'Unknown action'], 400);
}
