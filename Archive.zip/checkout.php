<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Borrow tools</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,600;0,9..40,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/app.css">
</head>
<body data-home="index.php">
  <div class="wrap">
    <h1>Borrow tools</h1>
    <p class="sub" id="operator-line"></p>

    <div id="borrowed-block" class="card" style="margin-bottom: 1rem;">
      <h2>Currently on loan to you</h2>
      <div id="borrowed-empty" class="sub" style="display: none;">No open loans — scan a tool below to borrow.</div>
      <table id="borrowed-table" style="display: none;">
        <thead><tr><th>Tool</th><th>Barcode</th><th>Checked out</th><th>Due back</th></tr></thead>
        <tbody id="borrowed-body"></tbody>
      </table>
    </div>

    <div class="card">
      <h2>Scan tool to borrow</h2>
      <p class="sub">Point the barcode or NFC reader at the label, or type the code.</p>
      <label for="scan">Barcode / NFC</label>
      <input type="text" id="scan" autocomplete="off" placeholder="Scan or enter code">
      <div id="scan-msg" style="margin-top: 0.75rem;"></div>
    </div>

    <div class="row-actions" style="margin-top: 1.5rem;">
      <button type="button" class="btn btn-primary" id="finish">Finish</button>
      <a class="btn btn-secondary" href="index.php">Cancel</a>
    </div>
  </div>
  <script src="assets/js/api.js"></script>
  <script src="assets/js/kiosk-idle.js"></script>
  <script>
    (function () {
      var params = new URLSearchParams(window.location.search);
      var operatorId = parseInt(params.get('operator_id') || '0', 10);
      var name = params.get('name') || 'Operator';
      if (!operatorId) {
        window.location.href = 'index.php';
        return;
      }

      document.getElementById('operator-line').textContent = name + ' — scan each tool, then tap Finish.';

      var scanInput = document.getElementById('scan');
      var scanMsg = document.getElementById('scan-msg');

      function showMsg(text, ok) {
        scanMsg.innerHTML = '';
        if (!text) return;
        var d = document.createElement('div');
        d.className = 'msg ' + (ok ? 'msg-success' : 'msg-error');
        d.textContent = text;
        scanMsg.appendChild(d);
      }

      function loadBorrowed() {
        tmApi('operator_borrowed', { operator_id: operatorId }).then(function (data) {
          if (!data.ok) return;
          var rows = data.borrowed || [];
          var empty = document.getElementById('borrowed-empty');
          var table = document.getElementById('borrowed-table');
          var body = document.getElementById('borrowed-body');
          body.innerHTML = '';
          if (!rows.length) {
            empty.style.display = 'block';
            table.style.display = 'none';
            return;
          }
          empty.style.display = 'none';
          table.style.display = 'table';
          rows.forEach(function (r) {
            var tr = document.createElement('tr');
            tr.innerHTML = '<td>' + escapeHtml(r.tool_name) + '</td><td>' + escapeHtml(r.barcode) + '</td><td>' +
              tmFormatDt(r.checkout_at) + '</td><td>' + tmFormatDt(r.expected_return_at) + '</td>';
            body.appendChild(tr);
          });
        });
      }

      function escapeHtml(s) {
        var d = document.createElement('div');
        d.textContent = s;
        return d.innerHTML;
      }

      function doCheckout() {
        var code = (scanInput.value || '').trim();
        if (!code) return;
        showMsg('', true);
        tmApi('checkout_tool', { operator_id: operatorId, code: code }).then(function (data) {
          scanInput.value = '';
          scanInput.focus();
          if (data.ok) {
            showMsg('Checked out: ' + (data.tool && data.tool.name ? data.tool.name : 'tool'), true);
            loadBorrowed();
          } else {
            showMsg(data.error || 'Checkout failed', false);
          }
        }).catch(function () {
          showMsg('Network error', false);
        });
      }

      scanInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          doCheckout();
        }
      });

      document.getElementById('finish').addEventListener('click', function () {
        window.location.href = 'index.php';
      });

      loadBorrowed();
      scanInput.focus();
    })();
  </script>
</body>
</html>
